function validateTextbox(){
var box = document.getElementById("Username");
var box2 = document.getElementById("Password");
box.style.border = "";
box2.style.border = "";
if (box.value.length < 5   ){
alert("please enter atleast 5 letter");
box.focus();
box.style.border = "solid 3px red";
return false;
}
if(box2.value.length < 6 ) {
	alert("password atleast 6 letter");
box2.focus();
box2.style.border = "solid 3px red";
return false;
}
return true;
}
