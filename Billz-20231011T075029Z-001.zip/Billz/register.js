function validateTextbox1(){

var box3 = document.getElementById("email");
var box4 = document.getElementById("user");
var box5 = document.getElementById("pass");
var box6 = document.getElementById("repeat");





if (box3.value.length < 5 || box4.value.length < 5 || box5.value.length < 5 || box6.value.length < 5 ){
alert("please enter atleast 5 letter");

box3.focus();
box3.style.border = "solid 3px red";
box4.focus();
box4.style.border = "solid 3px red";
box5.focus();
box5.style.border = "solid 3px red";
box6.focus();
box6.style.border = "solid 3px red";


return false;
}
return true;
}
